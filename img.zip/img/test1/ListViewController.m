//
//  ListViewController.m
//  test1
//
//  Created by wendy on 2022/4/25.
//

#import "ListViewController.h"
#import "DBManager.h"
#import "DataModel.h"
#import "List2ViewController.h"

@interface ListViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic, strong) NSArray *dataArray;

@end

@implementation ListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    
    [self.tableView registerClass:UITableViewCell.class forCellReuseIdentifier:NSStringFromClass(UITableViewCell.class)];
    [[DBManager shareManager] getAllVideo:^(NSArray<DataModel *> * _Nonnull res) {
        NSMutableArray *arr = [NSMutableArray array];
        for (DataModel *model in res) {
            if (![arr containsObject:model.title]) {
                [arr addObject:model.title];
            }
        }
        self.dataArray = arr;
        [self.tableView reloadData];
    }];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass(UITableViewCell.class) forIndexPath:indexPath];
    cell.textLabel.text = [self titleFromKey:self.dataArray[indexPath.row]];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    List2ViewController *vc = [[List2ViewController alloc] init];
    vc.hidesBottomBarWhenPushed = YES;
    vc.key = self.dataArray[indexPath.row];
    [self.navigationController pushViewController:vc animated:YES];
}

- (NSString *)titleFromKey:(NSString *)key{
    if ([key isEqualToString:@"0030100430220807"]) {
        return @"jianshen";
    }else if ([key isEqualToString:@"038037032054044083b"]){
        return @"jishu";
    }else if ([key isEqualToString:@"0050000330120807"]){
        return @"xinshijie";
    }
    return key;
}



@end
