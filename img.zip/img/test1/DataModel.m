//
//  DataModel.m
//  test1
//
//  Created by wendy on 2022/4/25.
//

#import "DataModel.h"

@implementation DataModel

@end
