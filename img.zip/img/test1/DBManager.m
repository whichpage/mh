//
//  DBManager.m
//  test1
//
//  Created by wendy on 2022/4/25.
//

#import "DBManager.h"
#import "FMDB.h"

static NSString *const currentVideoTableName = @"data_v1";
@interface DBManager ()
@property (nonatomic, strong) FMDatabaseQueue *databaseQueue;
@property (nonatomic, strong) FMDatabase *database;

@end

@implementation DBManager

+ (instancetype)shareManager {
    static DBManager *dbManager;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        dbManager = [[DBManager alloc] init];
    });
    return dbManager;
}

- (instancetype)init {
    if (self = [super init]) {
        NSString *filePath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0] stringByAppendingPathComponent:@"data_v1"];
        NSFileManager *fileManager = [NSFileManager defaultManager];
        BOOL isDir;
        BOOL isExit = [fileManager fileExistsAtPath:filePath isDirectory:&isDir];
        
        if (!isExit || !isDir){
            [fileManager createDirectoryAtPath:filePath withIntermediateDirectories:YES attributes:nil error:nil];
        }
        
        NSString *dbPath = [filePath stringByAppendingPathComponent:@"Database.db"];
        self.databaseQueue = [FMDatabaseQueue databaseQueueWithPath:dbPath];
        [self.databaseQueue inDatabase:^(FMDatabase *db) {
            self.database = db;
            if ([db open]){
                NSLog(@"数据库创建成功");
            }else {
                NSLog(@"数据库创建失败！");
            }
            NSString *sqlStr = [NSString stringWithFormat:@"CREATE TABLE '%@' ('id' INTEGER PRIMARY KEY AUTOINCREMENT  NOT NULL ,'absoluteString' VARCHAR(255),'title' VARCHAR(255),'section' VARCHAR(255),'row' VARCHAR(255),'imageData' VARCHAR(255))",currentVideoTableName];
            [db executeUpdate:sqlStr];
        }];
    }
    return self;
}

- (void)addSource:(DataModel *)source {
    if ([self hasDBSource:source]) { return; }
    
    NSString *sqlStr = [NSString stringWithFormat:@"INSERT INTO %@(absoluteString,title,section,row,imageData)VALUES('%@','%@','%@','%@','%@')",currentVideoTableName,source.absoluteString,source.title,source.section,source.index,source.imageData];
//    NSLog(@"addSource %@",sqlStr);
    [self.database executeUpdate:sqlStr];
}

- (DataModel *)hasDBSource:(DataModel *)source {
    NSString *sqlStr = [NSString stringWithFormat:@"SELECT * FROM %@ WHERE title = '%@' and section = '%@' and row = '%@' and imageData = '%@'",currentVideoTableName,source.title,source.section,source.index,source.imageData];
//    NSLog(@"hasSource %@",sqlStr);
    FMResultSet * set = [self.database executeQuery:sqlStr];
    while ([set next]) {
//        NSLog(@"信息数据库已存在");
        return [self sourceWithResultSet:set];
    }
//    NSLog(@"信息数据库不存在");
    return nil;
}

- (void)getAllVideo:(void (^)(NSArray<DataModel *> *))complete{
    NSMutableArray *res = [NSMutableArray array];
    NSString *sql = [NSString stringWithFormat:@"SELECT * FROM %@",currentVideoTableName];
    FMResultSet * set = [self.database executeQuery:sql];
    while ([set next]) {
        DataModel *source = [self sourceWithResultSet:set];
        [res addObject:source];
    }
    complete(res);
}

- (void)getVideoWithVideoInfo:(DataModel *)info Complete:(void (^)(NSArray<DataModel *> *))complete{
    NSMutableArray *result = [[NSMutableArray alloc] init];
    
    NSString *sqlStr = [NSString stringWithFormat:@"SELECT * FROM %@  WHERE title = '%@'",currentVideoTableName,info.title];
    if (info.section) {
        sqlStr = [sqlStr stringByAppendingFormat:@" and section = '%@'",info.section];
    }
    if (info.index) {
        sqlStr = [sqlStr stringByAppendingFormat:@" and row = '%@'",info.index];
    }
    
    sqlStr = [sqlStr stringByAppendingFormat:@" order by section*1 asc,row*1 asc,imageData*1 asc"];
    NSLog(@"%@",sqlStr);
    FMResultSet * set = [self.database executeQuery:sqlStr];
    while ([set next]) {
        [result addObject:[self sourceWithResultSet:set]];
    }
    
    complete(result);
}

- (DataModel *)sourceWithResultSet:(FMResultSet *)set{
    DataModel *source = [[DataModel alloc] init];
    source.absoluteString = [set stringForColumn:@"absoluteString"];
    source.title = [set stringForColumn:@"title"];
    source.section = [set stringForColumn:@"section"];
    source.index = [set stringForColumn:@"row"];
    source.imageData = [set stringForColumn:@"imageData"];
    return source;
}


@end
