//
//  DBManager.h
//  test1
//
//  Created by wendy on 2022/4/25.
//

#import <Foundation/Foundation.h>
#import "DataModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface DBManager : NSObject
+ (instancetype)shareManager;
- (void)addSource:(DataModel *)source;
- (void)getAllVideo:(void (^)(NSArray <DataModel *>*res))complete;
- (void)getVideoWithVideoInfo:(DataModel *)info Complete:(void (^)(NSArray <DataModel *>*result))complete;
@end

NS_ASSUME_NONNULL_END
