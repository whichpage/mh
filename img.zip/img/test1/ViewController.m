//
//  ViewController.m
//  test1
//
//  Created by wendy on 2022/4/25.
//

#import "ViewController.h"
#import <WebKit/WebKit.h>
#import "DBManager.h"
#import "DataModel.h"

@interface ViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (weak, nonatomic) IBOutlet WKWebView *webview;
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (nonatomic, strong, nonnull) NSFileManager *fileManager;
@property (nonatomic, strong) NSMutableSet *errSet;
@property (nonatomic, strong) NSMutableSet *errSet1;
@property (nonatomic, strong) NSMutableSet *errSet2;
@property (nonatomic, strong) NSMutableDictionary *count;
@property (nonatomic, strong) NSMutableDictionary *count1;
@property (nonatomic, strong) NSMutableDictionary *count2;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic, strong) NSMutableArray *logs;
@property (nonatomic, assign) BOOL stop;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.tableView registerClass:UITableViewCell.class forCellReuseIdentifier:NSStringFromClass(UITableViewCell.class)];
    [self.webview loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:@"https://www.rr8.us/038037032054044083b/41-1.html"]]];
    [self.logs addObject:[@"开始加载 " stringByAppendingString:self.webview.URL.absoluteString]];
}

- (IBAction)log {
    if (self.stop) {
        self.stop = NO;
        return;
    }
    [self.logs addObject:[@"innerHTML " stringByAppendingString:self.webview.URL.absoluteString]];
    [self.tableView reloadData];
    [self.webview evaluateJavaScript:@"document.documentElement.innerHTML" completionHandler:^(NSString * _Nullable string, NSError * _Nullable error) {
        [self addImage:string];
    }];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.logs.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass(UITableViewCell.class) forIndexPath:indexPath];
    NSDate *date = [NSDate date];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setTimeZone:[NSTimeZone defaultTimeZone]];
    [dateFormatter setLocale:[NSLocale currentLocale]];
    [dateFormatter setDateFormat:@"yyyy-MM-dd aHH:mm:ss"];
    
    cell.textLabel.text = [[self.logs[indexPath.row] stringByAppendingString:@"\n"] stringByAppendingString:[dateFormatter stringFromDate:date]];
    cell.textLabel.numberOfLines = 0;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

- (void)addImage:(NSString *)string{
    NSString *pattern = @"\"data:;base64,.*?\" ";
    NSError *error;
    NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:pattern options:NSRegularExpressionDotMatchesLineSeparators error:&error];
    if (!error) {
        NSArray <NSTextCheckingResult *>*results = [regex matchesInString:string options:NSMatchingReportProgress range:NSMakeRange(0, string.length)];
        if (results.count < 3) {
            
            if (![self.errSet containsObject:self.webview.URL.absoluteString]) {
                [self.logs addObject:[NSString stringWithFormat:@"异常☠️ %@ %lu",self.webview.URL.absoluteString,(unsigned long)results.count]];
                [self.tableView reloadData];
                [self.errSet addObject:self.webview.URL.absoluteString];
                self.imageView.image = nil;
                [self.webview reload];
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(10 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    [self log];
                });
                return;
            }
            if (![self.errSet1 containsObject:self.webview.URL.absoluteString]) {
                [self.count setValue:[NSString stringWithFormat:@"%lu",(unsigned long)results.count] forKey:self.webview.URL.absoluteString];
            }
            if (![self.errSet1 containsObject:self.webview.URL.absoluteString]) {
                [self.logs addObject:[NSString stringWithFormat:@"异常☠️☠️ %@ %lu",self.webview.URL.absoluteString,(unsigned long)results.count]];
                [self.tableView reloadData];
                [self.errSet1 addObject:self.webview.URL.absoluteString];
                self.imageView.image = nil;
                [self.webview reload];
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(30 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    [self log];
                });
                return;
            }
            if (![self.errSet2 containsObject:self.webview.URL.absoluteString]) {
                [self.count1 setValue:[NSString stringWithFormat:@"%lu",(unsigned long)results.count] forKey:self.webview.URL.absoluteString];
            }
            if (![self.errSet2 containsObject:self.webview.URL.absoluteString]) {
                [self.logs addObject:[NSString stringWithFormat:@"异常☠️☠️☠️ %@ %lu",self.webview.URL.absoluteString,(unsigned long)results.count]];
                [self.tableView reloadData];
                [self.errSet2 addObject:self.webview.URL.absoluteString];
                self.imageView.image = nil;
                [self.webview reload];
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(90 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    [self log];
                });
                return;
            }
            [self.count2 setValue:[NSString stringWithFormat:@"%lu",(unsigned long)results.count] forKey:self.webview.URL.absoluteString];
            NSString *c = [self.count objectForKey:self.webview.URL.absoluteString];
            NSString *c1 = [self.count1 objectForKey:self.webview.URL.absoluteString];
            NSString *c2 = [self.count2 objectForKey:self.webview.URL.absoluteString];
            if ([c isEqualToString:c1] && [c1 isEqualToString:c2]) {
                [self.logs addObject:[NSString stringWithFormat:@"一致😈 %@ %@ %@ %@",self.webview.URL.absoluteString,c,c1,c2]];
                [self.tableView reloadData];
            }else{
                [self.errSet removeObject:self.webview.URL.absoluteString];
                [self.errSet1 removeObject:self.webview.URL.absoluteString];
                [self.errSet2 removeObject:self.webview.URL.absoluteString];
                [self.count setValue:nil forKey:self.webview.URL.absoluteString];
                [self.count1 setValue:nil forKey:self.webview.URL.absoluteString];
                [self.count2 setValue:nil forKey:self.webview.URL.absoluteString];
                
                [self.logs addObject:[NSString stringWithFormat:@"重试😈 %@ %@ %@ %@",self.webview.URL.absoluteString,c,c1,c2]];
                [self.tableView reloadData];
                
                self.imageView.image = nil;
                [self.webview reload];
                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(8 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                    [self log];
                });
                return;
            }
        }
        BOOL success = YES;
        for (int i = 0; i<results.count; i++) {
            NSTextCheckingResult *result = results[i];
            NSString *res = [string substringWithRange:result.range];
            res = [res stringByReplacingOccurrencesOfString:@"\"data:;base64," withString:@""];
            res = [res stringByReplacingOccurrencesOfString:@"\" " withString:@""];
            NSData *imageData = [[NSData alloc] initWithBase64EncodedString:res options:NSDataBase64DecodingIgnoreUnknownCharacters];
            
            DataModel *model = [[DataModel alloc] init];
            model.absoluteString = self.webview.URL.absoluteString;
            model.title = [self.webview.URL.absoluteString componentsSeparatedByString:@"/"][3];
            model.section = [[self.webview.URL.absoluteString componentsSeparatedByString:@"/"][4] componentsSeparatedByString:@"-"][0];
            model.index = [[[self.webview.URL.absoluteString componentsSeparatedByString:@"/"][4] componentsSeparatedByString:@"-"][1] componentsSeparatedByString:@"."][0];
            model.imageData = [NSString stringWithFormat:@"%@_%@_%@_%d",model.title,model.section,model.index,i];
            
            if (imageData) {
                [self.logs addObject:[NSString stringWithFormat:@"存入 %@",model.imageData]];
                [self.tableView reloadData];
                self.imageView.image = [UIImage imageWithData:imageData];
                BOOL r = [self setData:imageData forKey:model.imageData];
                if (r) {
                    [[DBManager shareManager] addSource:model];
                }else{
                    success = NO;
                }
            }else{
                success = NO;
            }
        }
        if (success) {
            [self next:string];
            
        }else{
            [self.logs addObject:[NSString stringWithFormat:@"☠️☠️☠️ %@",self.webview.URL.absoluteString]];
            [self.tableView reloadData];
            self.imageView.image = nil;
            [self.webview reload];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(20 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [self log];
            });
        }
        
    }
}

- (void)next:(NSString *)string{
    NSString *pattern = @"=\".*?.html\"";
    NSError *error;
    NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:pattern options:NSRegularExpressionDotMatchesLineSeparators error:&error];
    if (!error) {
        NSArray <NSTextCheckingResult *>*results = [regex matchesInString:string options:NSMatchingReportProgress range:NSMakeRange(0, string.length)];
        NSString *res = [string substringWithRange:results.lastObject.range];
        NSString *s = [[res componentsSeparatedByString:@"href="].lastObject componentsSeparatedByString:@"\""][1];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self.webview loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:[@"https://www.rr8.us" stringByAppendingString:s]]]];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(8 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [self log];
            });
        });
    }
}

- (IBAction)print:(id)sender {
    [self.logs addObject:[NSString stringWithFormat:@"stop 🥶 %@",self.webview.URL.absoluteString]];
    [self.tableView reloadData];
    self.stop = YES;
}


- (BOOL)setData:(NSData *)data forKey:(NSString *)key {
    NSParameterAssert(data);
    NSParameterAssert(key);
    if (![self.fileManager fileExistsAtPath:[NSHomeDirectory() stringByAppendingPathComponent:@"Documents"]]) {
        [self.fileManager createDirectoryAtPath:[NSHomeDirectory() stringByAppendingPathComponent:@"Documents"] withIntermediateDirectories:YES attributes:nil error:NULL];
    }
    
    // get cache Path for image key
    NSString *cachePathForKey = [[NSHomeDirectory() stringByAppendingPathComponent:@"Documents"] stringByAppendingPathComponent:key];
    // transform to NSURL
    NSURL *fileURL = [NSURL fileURLWithPath:cachePathForKey];
    
    BOOL res = [data writeToURL:fileURL options:NSDataWritingAtomic error:nil];
    if (res) {
//        NSLog(@"保存成功");
        [self.logs addObject:[NSString stringWithFormat:@"success 🫡 %@",self.webview.URL.absoluteString]];
    } else {
//        NSLog(@"保存失败 %@",key);
        [self.logs addObject:[NSString stringWithFormat:@"error ☠️ %@",self.webview.URL.absoluteString]];
    }
    [self.tableView reloadData];
    return res;
}

- (NSFileManager *)fileManager{
    if (!_fileManager) {
        _fileManager = [NSFileManager defaultManager];
    }
    return _fileManager;
}

- (NSMutableSet *)errSet{
    if (!_errSet) {
        _errSet = [NSMutableSet set];
    }
    return _errSet;
}

- (NSMutableSet *)errSet1{
    if (!_errSet1) {
        _errSet1 = [NSMutableSet set];
    }
    return _errSet1;
}

- (NSMutableSet *)errSet2{
    if (!_errSet2) {
        _errSet2 = [NSMutableSet set];
    }
    return _errSet2;
}

- (NSMutableDictionary *)count{
    if (!_count) {
        _count = [NSMutableDictionary dictionary];
    }
    return _count;
}

- (NSMutableDictionary *)count1{
    if (!_count1) {
        _count1 = [NSMutableDictionary dictionary];
    }
    return _count1;
}

- (NSMutableDictionary *)count2{
    if (!_count2) {
        _count2 = [NSMutableDictionary dictionary];
    }
    return _count2;
}

- (NSMutableArray *)logs{
    if (!_logs) {
        _logs = [NSMutableArray array];
    }
    return _logs;
}

@end
