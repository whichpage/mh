//
//  List2ViewController.m
//  test1
//
//  Created by wendy on 2022/4/25.
//

#import "List2ViewController.h"
#import "DBManager.h"
#import "DataModel.h"
#import "ImageViewController.h"

@interface List2ViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic, strong) NSArray *dataArray;

@end

@implementation List2ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    [self.tableView registerClass:UITableViewCell.class forCellReuseIdentifier:NSStringFromClass(UITableViewCell.class)];
    
    DataModel *model = [[DataModel alloc] init];
    model.title = self.key;
    [[DBManager shareManager] getVideoWithVideoInfo:model Complete:^(NSArray<DataModel *> * _Nonnull result) {
        NSMutableArray *arr = [NSMutableArray array];
        for (DataModel *m in result) {
            if (![arr containsObject:m.section]) {
                [arr addObject:m.section];
            }
        }
        self.dataArray = arr;
        [self.tableView reloadData];
    }];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass(UITableViewCell.class) forIndexPath:indexPath];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.textLabel.text = self.dataArray[indexPath.row];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    ImageViewController *vc = [[ImageViewController alloc] init];
    DataModel *model = [[DataModel alloc] init];
    model.title =self.key;
    model.section = self.dataArray[indexPath.row];
    vc.model = model;
    [self.navigationController pushViewController:vc animated:YES];
}



@end


