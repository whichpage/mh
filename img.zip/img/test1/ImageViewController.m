//
//  ImageViewController.m
//  test1
//
//  Created by wendy on 2022/4/25.
//

#import "ImageViewController.h"
#import "ImageTableViewCell.h"

@interface ImageViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic, strong) NSArray *dataArray;

@end

@implementation ImageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    [self.tableView registerNib:[UINib nibWithNibName:NSStringFromClass(ImageTableViewCell.class) bundle:nil] forCellReuseIdentifier:NSStringFromClass(ImageTableViewCell.class)];
    [[DBManager shareManager] getVideoWithVideoInfo:self.model Complete:^(NSArray<DataModel *> * _Nonnull result) {
        self.dataArray = result;
        [self.tableView reloadData];
    }];
}
- (IBAction)previousClick:(id)sender {
    self.tableView.contentOffset = CGPointZero;
    NSInteger index = [self.model.section integerValue];
    if (index > 0) {
        index--;
        self.model.section = [NSString stringWithFormat:@"%ld",(long)index];
    }
    [[DBManager shareManager] getVideoWithVideoInfo:self.model Complete:^(NSArray<DataModel *> * _Nonnull result) {
        self.dataArray = result;
        [self.tableView reloadData];
    }];
}

- (IBAction)nextClick:(id)sender {
    self.tableView.contentOffset = CGPointZero;
    NSInteger index = [self.model.section integerValue];
    index++;
    self.model.section = [NSString stringWithFormat:@"%ld",(long)index];
    [[DBManager shareManager] getVideoWithVideoInfo:self.model Complete:^(NSArray<DataModel *> * _Nonnull result) {
        self.dataArray = result;
        [self.tableView reloadData];
    }];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.dataArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    DataModel *model = self.dataArray[indexPath.row];
    UIImage *image = [self getCacheImageUseImagePath:model.imageData];
    if (image) {
        return [UIScreen mainScreen].bounds.size.width * image.size.height / image.size.width;
    }
    return 0;
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    ImageTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass(ImageTableViewCell.class) forIndexPath:indexPath];
    DataModel *model = self.dataArray[indexPath.row];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.imageV.image = [self getCacheImageUseImagePath:model.imageData];
    return cell;
}

- (UIImage *)getCacheImageUseImagePath:(NSString *)imagePath{
    
    return [UIImage imageWithData:[self dataForKey:imagePath]]?:[UIImage imageNamed:@"error"];
}

- (NSData *)dataForKey:(NSString *)key {
    NSParameterAssert(key);
    NSString *filePath = [[NSHomeDirectory() stringByAppendingPathComponent:@"Documents"] stringByAppendingPathComponent:key];
    NSData *data = [NSData dataWithContentsOfFile:filePath options:NSDataReadingMappedIfSafe error:nil];
    if (data) {
        return data;
    }
    
    data = [NSData dataWithContentsOfFile:filePath.stringByDeletingPathExtension options:NSDataReadingMappedIfSafe error:nil];
    if (data) {
        return data;
    }
    
    return nil;
}

@end
