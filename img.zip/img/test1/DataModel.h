//
//  DataModel.h
//  test1
//
//  Created by wendy on 2022/4/25.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface DataModel : NSObject

@property (nonatomic, strong, nullable) NSString *absoluteString;
@property (nonatomic, strong, nullable) NSString *title;
@property (nonatomic, strong, nullable) NSString *section;
@property (nonatomic, strong, nullable) NSString *index;
@property (nonatomic, strong, nullable) NSString *imageData;
@end

NS_ASSUME_NONNULL_END
